import os
import time
import random
import globalVariables # imports the global variables
import Pasta # import these sinces we are calling the functions from here instead of returning to the main to call them
import Spices # "
import Deli # "
import CheckOut # "

##pastachosen = 0
##meatchosen = 0
##spicechosen = 0
##seenitalready = 0

def storefront():
#    seenitalready = 0
#    from MainGame import seenitalready Now being imported from globalVariables
##    print(globalVariables.seenitalready) # Used for testing

    if globalVariables.seenitalready == 0:
        print("The entire store lies open before you. You can see for aisles and aisles, each row loaded with food.")
        print()
        time.sleep(3)
        print("Your dinner is here. Waiting for you.")
        print("You spent ages imagining the delicious pasta dinner you were going to have. It had three parts.")
        print()
        time.sleep(3)
        print("One, pasta. Obviously.")
        print()
        time.sleep(2)
        print("Two, meat. Something savory to work texture into the pasta.")
        print()
        time.sleep(2)
        print("And finally, three, condiments. Herbs, sauce, SOMETHING to spice it up. You're not picky.")
        print()
        time.sleep(5)
        print("You have a basic idea where each of them is supposed to be. All you have to do is go there!")
        print()
        globalVariables.seenitalready = 1
    elif globalVariables.seenitalready == 1: #Skips the intro paragraph if the player has already seen it once.
        if globalVariables.Victory == True: #If the player has won but reaches this point, automatically terminates the module.
            return()
        else:
            print("You're back at the storefront. Time to pick something new!")
            print()
    pathchoice = 0
    print("In your inventory, you have...") #Tracks what the player has in their inventory.
    inventory = "Your wallet,"
    if globalVariables.pastachosen == 0 and globalVariables.spicechosen == 0 and globalVariables.delichosen == 0:
        inventory = inventory + " and nothing else."
    if globalVariables.pastachosen == 1: 
        inventory = inventory + globalVariables.pastachoice + ","
    if globalVariables.spicechosen == 1:
        inventory = inventory + globalVariables.spicechoice + ","
    if globalVariables.delichosen == 1:
        inventory = inventory + globalVariables.delichoice + ","
    print(inventory)
    print()
    print("You can make the following decisions:")
    pathchosen = "0"
    while pathchosen == "0":
        time.sleep(3)
        print("1. Head over to the pasta aisle and grab some delicious pasta.")
        print("2. Head over to the deli to get some meat.")
        print("3. Head over to the spice rack to get some condiments.")
        print("4. Head over to the cash register, to check out and go home. THIS WILL END THE GAME!")
        pathchoice = input("So, which will it be?")
        print()
        if pathchoice == "1":
            print("You head out to the pasta aisle, on the hunt for elusive noodles.")
            print()
            time.sleep(3)
            pathchosen = 1
            globalVariables.seenitalready = 1
            Pasta.pastaisle()
        elif pathchoice == "2":
            print("You head out to the deli, hungry for protein.")
            print()
            time.sleep(3)
            globalVariables.seenitalready = 1
##            print(globalVariables.seenitalready)
            pathchosen = 1
            Deli.delicatessen()
            #return() # Used for testing
            Deli.delicatessen()
        elif pathchoice == "3":
            print("You head out to the spice racks, holding your nostrils shut.")
            time.sleep(3)
            globalVariables.seenitalready = 1
            pathchosen = 1
            Spices.spicerack()
        elif pathchoice == "4":
            print("You take your place in line, and wait for your time to come.")
            print()
            time.sleep(3)
##            globalVariables.delichosen = 1
##            globalVariables.delichoice = "frozen meatballs"
##            globalVariables.spicechosen = 1
##            globalVariables.spicechoice = "black pepper grinder"
##            globalVariables.pastachoice = "fettuccini noodles"
##            globalVariables.pastachosen = 1
            pathchosen = 1
            CheckOut.checkout()
        else:
            print("Error, please enter only 1, 2, 3, or 4.")
#print(storefront()) Don't need this statement since we are calling it from the Prologue
