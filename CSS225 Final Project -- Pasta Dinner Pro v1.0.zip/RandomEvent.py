import time
import os
import random
import DeathScreen
##eventchance = random.randint(1,7)
def randomevent(eventchance): #evenchance occurs in Deli, Pasta, and Spice aisles. A random integer from 1 to 6 is picked. Which event below is triggered depends on what the integer is.
    print("Something unexpected is coming down the aisle towards you!")
    EventResolved = 0
    time.sleep(2)
    if eventchance == 1:
        print("You find yourself next to the clearance rack! Questionable things at bargain prices are spread out before you.")
        print()
        time.sleep(3)
        print("1. Browse through the rack.")
        print("2. Take everything you can carry.")
        print("3. Leave it be.")

        while EventResolved == 0:
            EventChoice = input("You decide to...")
            if EventChoice == "1":
                print("You pick through the clearance rack. Soon enough, you find yourself stuffing your cart with a bag of Christmas marshmallows and a bottle of obnoxiously-flavored wine.")
                print()
                time.sleep(3)
                EventResolved = 1
                return()
            elif EventChoice == "2":
                print("You drag everything on the shelf into your cart. Something clatters against something else, causing a tremendous chain reaction!")
                print()
                time.sleep(3)
                print("In an instant, you are buried beneath kitsch, crap, and barely edible 'food'!")
                print("---You Have Become One With The Crap---")
                EventResolved = 1
                DeathScreen.deathscreen()
            elif EventChoice == "3":
                print("You decide you have more than enough crap in your home. You keep going to the aisle you were interested in.")
                print()
                time.sleep(3)
                EventResolved = 1
                return()
            else:
                print("Error, please enter 1, 2, or 3.")


    elif eventchance == 2:
        print("You find yourself stuck behind someone in a mobility scooter! You can barely see past their amazing fatness, let alone get past them.")
        print()
        time.sleep(3)
        print("1. Wait for a chance to rush past her at the next intersection.")
        print("2. Double back and find another route.")
        print("3. Try to push past them.")
        while EventResolved == 0:
            EventChoice = input("What do you do?")
            if EventChoice == "1":
                print("It takes a long, LONG while, but eventually the both of you reach the end of the aisle. Your surge past them like a bat out of hell, and find yourself free to move on to the next aisle!")
                print()
                time.sleep(3)
                EventResolved = 1
                return()
            elif EventChoice == "2":
                print("You retrace your steps. Thankfully, there isn't a second fat person BEHIND you. It takes you a little longer, but eventually you get to where you wanted to go!")
                print()
                time.sleep(3)
                EventResolved = 1
                return()
            elif EventChoice == "3":
                print("You press yourself to the side of the aisle, and begin trying to squeeze past the fatso's horrible jellyrolls.")
                print()
                time.sleep(2)
                print("You are quickly smothered in a layer of fat.")
                print("---Your Screams Do Not Reach The Surface.---")
                EventResolved = 1
                DeathScreen.deathscreen()
            else:
                print("Error, please enter 1, 2, or 3.")



    elif eventchance == 3:
        print("You come across a man and his service dog. He looks friendly, and his dog is a nice yellow Labrador!")
        print()
        time.sleep(3)
        print("1. Pet the dog!")
        print("2. Scratch the dog's ears!")
        print("3. Ignore the dog.")
        while EventResolved == 0:
            EventChoice = input("Which do you do?")
            if EventChoice == "1":
                print("You pet the dog. It is very happy! Good dog.")
                print()
                time.sleep(2)
                EventResolved = 1
                return()
            elif EventChoice == "2":
                print("You scratch the dog's ears. It likes it! Good dog.")
                print()
                time.sleep(2)
                EventResolved = 1
                return()
            elif EventChoice == "3":
                print("You know it's better not to confuse service dogs. The owner appreciates you!")
                print()
                time.sleep(2)
                EventResolved = 1
                return()
            else:
                print("Error, please enter 1, 2, or 3.")

    elif eventchance == 4:
        print("You come across a store employee pushing a large, heavy dolly full of goods. He's only somewhat blocking your way, and you need to get past him somehow.")
        print()
        time.sleep(3)
        print("1. Push forward. The customer is always right, he'll have to move out of your way!")
        print("2. Wait patiently for him to pass.")
        print("3. Squeeze past him!")
        while EventResolved == 0:
            EventChoice = input("What do you do?")
            if EventChoice == "1":
                print("You begin pushing your cart forward, straight in his path. There is a moment of tension, and...")
                print()
                time.sleep(3)
                print("---You Have Been Crushed Beneath The Wheels Of Retail.---")
                EventResolved = 1
                DeathScreen.deathscreen()
            elif EventChoice == "2":
                print("You wait for an uncomfortably long while as he finishes unloading his dolly. As he pushes his (now much lighter) dolly past you, he doesn't even acknowledge you. Oh well.")
                print()
                time.sleep(3)
                EventResolved = 1
                return()
            elif EventChoice == "3":
                print("You angle your cart weirdly, and try to make a path around him. Miraculously, you make it! You leave the poor guy behind and make your way to your destination.")
                print()
                time.sleep(3)
                EventResolved = 1
                return()
            else:
                print("Error, please enter 1, 2, or 3.")


    elif eventchance == 5:
        print("You find yourself in the Alcohol aisle! Literal tons of booze surround you, from ale to wine, and everything in between!")
        print()
        time.sleep(3)
        print("1. Pick out a six-pack of beer.")
        print("2. Stop yourself from buying anything.")
        print("3. Browse through the hard liquor available.")
        while EventResolved == 0:
            EventChoice = input("What do you do?")
            if EventChoice == "1":
                print("You find a brand from Wisconsin that you can't pronounce. Well, if it's German, it's got to be good. You put it in your cart and head to the aisle you were looking for.")
                print()
                time.sleep(3)
                EventResolved = 1
                return()
            
            elif EventChoice == "2":
                print("Good on you, you teetotaller, you! Catching a nice, natural high from your own smug aura, you return to the aisle you were looking for.")
                print()
                time.sleep(3)
                EventResolved = 1
                return()
                
            elif EventChoice == "3":
                print("You find a bottle of... cotton candy celery vodka? Equally amazed and disgusted, you put it in your cart. You can't ever imagine actually DRINKING it, but it'll help keep you company at home.")
                print()
                time.sleep(3)
                EventResolved = 1
                return()
            else:
                print("Error, please enter 1, 2, or 3.")


    elif eventchance == 6:
        print("You find yourself in the Produce aisle! Fruits and veggies and other healthy crap are all around you.")
        print()
        time.sleep(3)
        print("1. The store recently had some GMO Corn brought in. Why not buy an ear or two?")
        print("2. You COULD use some more apples, actually.")
        print("3. Buy a sack of potatoes, some onions, celery, lettuce, carrots...")
        while EventResolved == 0:
            EventChoice = input("What do you do?")
            if EventChoice == "1":
                print("You pick a promising ear from the bin. The rest of the bin seems to be a little restless.")
                print()
                time.sleep(3)
                print("Suddenly, the corn you're holding goes feral, and starts attacking you! Its brothers and sisters join in, reducing you to a skeleton in mere seconds!")
                print("---You Got Corn'd, Son!---")
                EventResolved = 1
                time.sleep(3)
                DeathScreen.deathscreen()
            elif EventChoice == "2":
                print("You buy a pound or so of good ol' apples. You can't tell if they're Red Delicious or Gala, but it doesn't really matter to you. Fruit in tow, you go back to the aisle you were looking for.")
                print()
                time.sleep(3)
                EventResolved = 1
                return()
            elif EventChoice == "3":
                print("By the time you're finished collecting produce, your cart barely has any room left! You're sure you've got space for whatever you're getting in the next aisle, though. You move on.")
                print()
                time.sleep(3)
                EventResolved = 1
                return()
            else:
                print("Error, please enter 1, 2, or 3.")
##print(randomevent(eventchance))
