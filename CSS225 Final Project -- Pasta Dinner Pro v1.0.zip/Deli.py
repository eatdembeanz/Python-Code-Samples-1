import time
import random
import sys
import globalVariables
import RandomEvent
import DeathScreen
import HubWorld

def delicatessen():
    if globalVariables.delichosen == 1:
        if globalVariables.Victory == True:
            return() #If the player has won but still appears here, automatically cancels this module.
        else:
            time.sleep(3)
            print("But you've already picked out some meat, so you head back to the storefront.")
            time.sleep(2)
            HubWorld.storefront()

    eventchance = random.randint(1,6)
    RandomEvent.randomevent(eventchance)
    print("The deli aisle is stocked with a wide variety of meat, as you expected. Fish, pork, beef, chicken, and all sorts of processed meat are stuffed in coolers along the wall.")
    print()
    time.sleep(2)
    print("A counter to your right stocks the good stuff; the freshest fish and the finest cuts, all waiting for you.")
    print()
    time.sleep(2)
    print("An old lady is staring hawkishly at the poor worker at the counter, squawking angrily as he cuts a lump of honey-baked ham into thinner and thinner slices. He's been at it a long while, it seems.")
    print()
    time.sleep(2)
    print("You remind yourself of what you need from here: MEAT. You look around the area.")
    print()
    time.sleep(2)
    print("1. Wait for the deli worker to help you. He should be finished soon, right?")
    print("2. Pick out a whole frozen chicken. If you make a LOT of meat, you can have it for leftovers!")
    print("3.Pick out a pack of sliced meat. You can't tell what it IS, but it's meat!")
    print("4. Pick out a bag of frozen meatballs.")
    print("5. Pick out a package of filleted fish.")
    print()
    while globalVariables.delichosen == 0: #Loop runs as long as the player hasn't picked out any valid meats.
        delichoice = input("Examining your options, you decide to...")
        if delichoice == "1":
            print("You wait. And wait. And wait. And wait.")
            print()
            time.sleep(5)
            print("By the time the worker slices the meat thin enough for the old lady's liking, you yourself have grown ancient")
            print()
            time.sleep(3)
            print("Happily, you pick out a very nice piece of meat, and ask for it sliced thinly.")
            print()
            time.sleep(2)
            print("No, thinner. A little thinner. No, no, THINNER...")
            print()
            time.sleep(1)
            print("---You Have Become That Which You Hate---")
            DeathScreen.deathscreen()
        elif delichoice == "2":
            print("Frozen chicken is heavier than you thought! This thing must weigh more than a dozen pounds! You put all your strength into lifting up the titanically heavy poultry.")
            print()
            time.sleep(2)
            print("With a Herculean scream, you successfully lift the chicken over your head! Victory is yours!!!")
            print()
            time.sleep(2)
            print("You arms can't hold it up forever, though. The chicken slips through your hands, landing directly on your head. Everything above your neck is caved in, killing you instantly.")
            print()
            time.sleep(2)
            print("---You Died, Meathead.---")
            DeathScreen.deathscreen()
        elif delichoice == "3":
            globalVariables.delichosen = 1
            globalVariables.delichoice = "sliced meat"
            print("You put some... baloney? Salami? Sliced turkey? It doesn't really matter, it's in your cart now. You head back to the storefront with your prize in tow.")
            print()
            time.sleep(3)
            HubWorld.storefront()
        elif delichoice == "4":
            globalVariables.delichosen = 1
            globalVariables.delichoice = "frozen meatballs"
            print("You toss a half-pound bag of frozen meatballs in your cart. You head back to the storefront, whistling peppy accordion music in your head.")
            print()
            time.sleep(3)
            HubWorld.storefront()
        elif delichoice == "5":
            globalVariables.delichosen = 1
            globalVariables.delichoice = "fish filets"
            print("You pick out a nice salmon filet, and drop it in your cart. You head back to the storefront, feeling very beary.")
            print()
            time.sleep(3)
            HubWorld.storefront()
        else:
            print("Error, please enter 1, 2, 3, 4, or 5.")
