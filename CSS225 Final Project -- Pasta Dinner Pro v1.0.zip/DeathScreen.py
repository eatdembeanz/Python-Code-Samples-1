import time
import os
import random
import HubWorld
import globalVariables

def deathscreen():
    globalVariables.deathcounter = globalVariables.deathcounter + 1 #Adds one to a counter that counts how many times the player died.
    globalVariables.meatchosen = 0
    globalVariables.pastachosen = 0
    globalVariables.spicechosen = 0
    globalVariables.meatchoice = 0
    globalVariables.spicechoice = 0
    globalVariables.pastachoice = 0 #Resets all of the player's choices.
    print("Your life flashes before your eyes as the last breath leaves your body. YOU HAVE DIED.")
    time.sleep(3)
    print("But wait...")
    time.sleep(1)
    print("You feel a tremendous wrench – the hand of God coming down to wipe clean the temporal chalkboard.")
    time.sleep(4)
    print("'My Child', The LORD says, 'You Have Royally Screwed Up. How Could This Have Happened?'")
    time.sleep(3)
    print("'I Can Give You A Chance To Go Back, And Make Things Right.'")
    time.sleep(2)
    print("You see yourself at the entrance of Jewel, the moment you stepped through the doors.")
    time.sleep(3)
    print("'Will You Return To The Past, To Find Your Promised Pasta?' The LORD asks. Yes, or No?")
    deathanswer = str(input(">"))
    if deathanswer == "Yes" or deathanswer == "yes":
        HubWorld.storefront() #Returns player to the storefront
    elif deathanswer == "No" or deathanswer == "no":
        return(quit())
    else:
        print("'I'm Sorry, I Didn't Catch That. I'll Just Assume You Want To Go Back.'")
        HubWorld.storefront() #Returns player fo the storefront
        
