
#Benjamin Page
#3/20/2019

##Global Variable file for storing variables that must be recalled and updated throughout the game.
def gVariables():
#    global Choice1 - Not sure if you wanted these as global or not
    global playername
    global pastachosen
    global delichosen
    global spicechosen
    global deathcounter
    global delichoice
    global spicechoice
    global pastachoice
    global seenitalready
    global Victory
    deathcounter = 0 #Determines how many times the player died
    pastachosen = 0 #Determines whether the player has successfully chosen pasta
    delichosen = 0 #Determines whether the player has chosen meat
    spicechosen = 0 #Determines whether the player has chosen spices
    seenitalready = 0 #Determines whether the player has seen the prologue already.
    delichoice = "" #Tracks which meat the player has picked out.
    spicechoice = "" # Tracks which spice the player has picked out
    pastachoice = "" #Tracks which pasta the player has picked out
    playername = "Wingus" # Default state of the player's name. Ideally, it shouldn't stay like this.
    Victory = False #Tracks whether the player has won the game by reaching CheckOut with pasta, meat, and spice in their inventory.
