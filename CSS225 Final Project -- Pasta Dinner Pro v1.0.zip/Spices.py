import os
import time
import random
import RandomEvent
import DeathScreen
import HubWorld
import globalVariables

def spicerack():
    if globalVariables.spicechosen != 0:
        if globalVariables.Victory == True:
            return()
        else:
            print("You already picked out some spice! You're not staying around here any longer than you need to! You return to the storefront.")
            HubWorld.storefront()
    eventchance = random.randint(1,6)
    RandomEvent.randomevent(eventchance)
    print("A river of tears starts flowing from your eyes the instant you walk into the spice aisle.")
    print()
    time.sleep(1)
    print("The air here is FILLED with a thin cloud of spices!A cloud of garlic, cinammon, nutmeg, and red pepper fights for real estate in your nose and eyes!")
    print()
    time.sleep(4)
    print("There's a ton of different spices here, but you're only interested in bringing back one.")
    print()
    time.sleep(3)
    print("Better pick it out soon, this atmosphere is absolutely murderous!")
    print()
    time.sleep(2)
    print("There'a lot of spice around you, but you can see a few promising options:")
    print("1. Oregona")
    print("2. BBQ spice rub")
    print("3. Onion powder")
    print("4. Black pepper")
    print("5. A deep breath.")
    print("6. Whatever you can carry.")
    print("7.An unmarked salt shaker.")
    while globalVariables.spicechosen == 0:
        spicechoice = input("Pressed for time and desperate to get out, you take...")
        
        if spicechoice == "2":
            globalVariables.spicechosen = 1
            print("You snatch the spice of your choice and run from the aisle, gagging and coughing. Soon enough, you're back at the front of the store.")
            print()
            globalVariables.spicechoice = "BBQ spice rub"
            time.sleep(4)
            #print(globalVariables.spicechosen)#Testing print
            #print(globalVariables.spicechoice)
            HubWorld.storefront()

        elif spicechoice == "3":
            globalVariables.spicechosen = 1
            globalVariables.spicechoice = "bottle of onion powder"
            print("You hastily grab a bottle of powdered onion, and heave yourself out of the aisle. When you get back to the front of the store, you're happy to NEVER have to go back there again!")
            print()
            time.sleep(3)
            HubWorld.storefront()

        
        elif spicechoice == "4":
            globalVariables.spicechosen = 1
            globalVariables.spicechoice = "black pepper grinder"
            print("You rip a pepper grinder from the shelf, and hurry out of the aisle. Spice in hand, you return to the front of the store.")
            print()
            time.sleep(3)
            HubWorld.storefront()

        
        elif spicechoice == "6":
            print("You grab several fistfuls of shakers, bottles, and sprigs. To your incredible surprise, none of them are deadly!")
            print()
            print("You slam the potpourri of condiments into your cart, and make your way back to the front of the store.")
            print()
            globalVariables.spicechoice = "variety of herbs and spices"
            globalVariables.spicechosen = 1
            time.sleep(4)
            HubWorld.storefront()

        
        elif spicechoice == "1":
            print("You take a strangely-marked bottle of herbs from the shelf. The label on the bottle says 'Oregona', with a logo of a wagon and the state of Oregon emblazoned on it.")
            print()
            time.sleep(4)
            print("Almost immediately, you are possessed with an odd urge. No longer do you hunger for pasta. Now, you only feel the need to GO WEST.")
            print()
            time.sleep(4)
            print("You exit the store, leaving everything you were carrying behind. As you step into your car, you gaze at the setting sun. The trip along the Oregon Trail will be difficult, but you know a new life awaits you out on the western coast.")
            print()
            time.sleep(5)
            print("---You Have Died Of Dysentery---")
            time.sleep(4)
            DeathScreen.deathscreen()

        
        elif spicechoice == "5":
            print("You inhale deeply, hoping to desensitize yourself to the cloud of toxic spices.")
            print()
            time.sleep(4)
            print("Almost immediately, you double over, coughing and gagging. The airborne spice, merrily tearing the shit out of your throat, slowly work their way into your lungs.")
            print()
            time.sleep(4)
            print("As the soft flesh of your lungs dissolves into a richly-seasoned mess, you briefly wonder why you ever thought this was a good idea.")
            print()
            time.sleep(4)
            print("---You Are Dead, And Delicious---")
            DeathScreen.deathscreen()

        
        elif spicechoice == "7":
            print("You're not sure what's IN this shaker, but salt has never steered you wrong before. You take it with you, pay for it alongside the rest of your shopping list, and use it in a delicious pasta meal.")
            print()
            time.sleep(4)
            print("As you scoop up the last few morsels of pasta, you note that the salt didn't really taste or smell like ANYTHING. It was very quite disappointing and bland.")
            print()
            time.sleep(4)
            print("That night, you die horribly and painfully from arsenic poisoning.")
            print()
            time.sleep(2)
            print("---Arsenic Is A Salt Too!---")
            DeathScreen.deathscreen()

        
        else:
            print("Error, please enter 1, 2, 3, 4, 5, 6, or 7.")
 

