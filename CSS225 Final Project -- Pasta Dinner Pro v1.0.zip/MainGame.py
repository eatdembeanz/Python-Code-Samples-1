import time
import random
import sys
import globalVariables # imports the global variables
import Prologue
import RandomEvent
import Spices
import HubWorld
import Deli
import DeathScreen
import CheckOut

globalVariables.gVariables() # initiallizes the global variables

##print(globalVariables.seenitalready) # Used for testing

Prologue.parkinglot() #Starts the game.

##print(globalVariables.seenitalready) Used for testing.
