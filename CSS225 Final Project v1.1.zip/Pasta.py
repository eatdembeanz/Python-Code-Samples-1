import os
import time
import random
import RandomEvent
import DeathScreen
import HubWorld
import globalVariables

def pastaisle():

    if globalVariables.pastachosen != 0:
        if globalVariables.Victory == True: #If the player has won, but reaches this point, automatically terminates the module.
            return()
        else:
            print("You've already got some pasta! You head back to the front of the store.") #If the player already has pasta, returns them to the storefront.
            HubWorld.storefront()

    eventchance = random.randint(1,6) #Selects a number from 1 to 6 and assigns it to eventchance.
    RandomEvent.randomevent(eventchance) #Triggers one of six random events by calling the RandomEvent module, then continues with the Pasta module
##    print(pastachosen)
    print("Pasta and pasta sauce stretch out as far as the eye can see. THIS is what you were looking for.")
    print()
    time.sleep(4)
    print("At the other end of the aisle is a brown-haired woman, also picking out pasta. She seems nice!")
    print()
    time.sleep(2)
    print("There is also a phone booth here. What an odd thing, not only in 2019, but in a grocery store.")
    print()
    time.sleep(4)
    print("Rows and rows of delicious noodles are lined up around you. Any one of these will suit your needs... but WHICH one?")
    print()
    time.sleep(4)
    print("1. Enter the phone booth. It looks interesting, why not check it out?")
    print("2. Talk to the brown-haired lady.")
    print("3. Pick out some lasagna.")
    print("4. Pick out some macaroni.")
    print("5. Pick out some fettuccini.")
    print("6. Pick out some... angola? Agnaletto? The little pocket-shaped things.")
    print("7. Pick out some borzoi.")
    print()
    
    while globalVariables.pastachosen == 0: #Loop runs as long as the player hasn't picked a valid pasta at some point.
        pastachoice = input("You decide to...")
        if pastachoice == "4":
            globalVariables.pastachosen = 1
            print("You pick out some macaroni, and shake it experimentally. It makes a beautiful clattering sound as the golden noodles rattle against each other.")
            print("Smiling internally and externally, you return to the front of the store.")
            print()
            globalVariables.pastachoice = "macaroni noodles"
            time.sleep(3)
##            print(globalVariables.pastachoice,globalVariables.pastachosen)#For Testing Purposes
            HubWorld.storefront()

        
        elif pastachoice == "3":
            print("You pick out some lasagne, and drop it in your cart. Grumbling about Mondays, you go back to the front of the store.")
            print()
            globalVariables.pastachoice = "lasagne noodles"
            globalVariables.pastachosen = 1
            time.sleep(3)
##            print(globalVariables.pastachoice,globalVariables.pastachosen)#For Testing Purposes
            HubWorld.storefront()

        
        elif pastachoice == "5":
            print("You pick out a box of thin fettuccini noodles. As it lands in your cart, you chuckle about how funny the word 'fettuccini' is. You head back to the front of the store.")
            print()
            globalVariables.pastachoice = "fettuccini noodles"
            globalVariables.pastachosen = 1
            time.sleep(3)
##            print(globalVariables.pastachoice,globalVariables.pastachosen)#For Testing Purposes
            HubWorld.storefront()

        
        elif pastachoice == "6":
            print("You pick out a box of... the noodles you picked out. They look like itty bitty pierogis. You head back to the front of the store, thinking about potatoes")
            print()
            globalVariables.pastachoice = "agnoletti noodles"
            globalVariables.pastachosen = 1
##            print(globalVariables.pastachoice,globalVariables.pastachosen)#For Testing Purposes
            time.sleep(3)
            HubWorld.storefront()

        
        elif pastachoice == "1":
            print("You open the door to the phone booth, and look inside. Sure enough, it's a phone booth! You check the coin return slot for any spare change, just in case.")
            print()
            time.sleep(4)
            print("Suddenly, the phone booth's door slams shut behind you! A panel next to the phone slides open, revealing a video feed of a serious-looking bald man in a nice suit.")
            print()
            time.sleep(4)
            print("'Agent!' the man barks, 'Where have you BEEN?! You're thirty minutes late to the briefing, and Doctor Killhoff could activate his Discombobulator at any moment!'")
            print()
            time.sleep(4)
            print("Before you can respond, the man cuts you off. 'Nevermind. We'll fill you in on the car ride over to the laboratory. HQ out!!'")
            print()
            time.sleep(4)
            print("The floor of the phone booth drops out, sending you plunging into darkness and an adventure far beyond the scope of this simple game.")
            print()
            time.sleep(4)
            print("---You Have Been Made Into A Super Spy---")
            DeathScreen.deathscreen()

        
        elif pastachoice == "2":
            print("You walk up to the brown-haired lady, and say hi. 'H-hey,' you stammer coolly, slicking back your hair. 'Come here often?'")
            print()
            time.sleep(4)
            print("The lady looks over to you. Her eyes narrow. 'Did you just smalltalk me?' she asks. You nod, winking. 'Yeah, I did. So, how're you doing?'")
            print()
            time.sleep(4)
            print("The lady's mouth opens into a crooked snarl. 'SMALL TALKER!!!' she shrieks, and intantly all eyes in the store are on you.")
            print()
            time.sleep(4)
            print("In short order, you are tied up at the stake by dozens of furious customers. They all chant 'Small-talker! Small-talker!' as the store's ceremonial shaman sets the tinder at your feet on fire.")
            print("---You Have Made A Slight Faux-Pas---")
            time.sleep(4)
            DeathScreen.deathscreen()

        
        elif pastachoice == "7":
            print("You pick out a featureless box labeled 'Borzoi', and give it a shake. Instead of rattling pasta, you hear something heavy tumbling around in there. Curious, you open up the top of the box, and peer in.")
            print()
            time.sleep(4)
            print("Suddenly, a fully-grown Borzoi wolfhound surges out of the box! Its powerful jaws close around your arm, forcing you to drop the box.")
            print()
            time.sleep(4)
            print("Dog after dog piles out of the opened box, like a clown car from hell! Within seconds, you are torn apart by a horde of hungry puppers!")
            print("---The Eater Has Become The Eatened---")
            time.sleep(3)
            DeathScreen.deathscreen()

        
        else:
            print("Error, please pick a number from 1 to 7.")

##print(pastaisle())
