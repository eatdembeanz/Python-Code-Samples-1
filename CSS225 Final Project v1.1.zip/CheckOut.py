import random
import time
import sys
import DeathScreen
import globalVariables

def checkout():
    print("After quite a while of waiting, it's finally your turn to check out. You look into your cart, and...")
    if globalVariables.pastachosen == 0 and globalVariables.delichosen == 0 and globalVariables.spicechosen == 0: #Triggers if the player has NO ingredients. Precludes other failure states.
        print("Oh no! You forgot EVERYTHING!")
        print()
        time.sleep(0.5)
        print("You idiot! You dingus! You absolute slackass dipstick!")
        print()
        time.sleep(0.5)
        print("You curl up into a ball and begin sobbing incoherently. Shortly after, you die from embarrassment.")
        print()
        time.sleep(2)
        print("---You Have Left This World The Way You Came In: Stupid, Crying, And Disappointing Everyone---")
        DeathScreen.deathscreen()

    
    elif globalVariables.pastachosen == 0: #Triggers if the player doesn't have pasta.
        print("You forgot the pasta!")
        print()
        time.sleep(0.5)
        print("You return home and cook a thoroughly pasta-free meal. There are no chewy golden noodles to brighten your day.")
        print()
        time.sleep(2)
        print("---The Point Of The Game Was To Make Pasta---")
        DeathScreen.deathscreen()

    
    elif globalVariables.spicechosen == 0: #Triggers if the player doesn't have spice.
        print("You forgot the spices!")
        print()
        time.sleep(0.5)
        print("You return home and cook a very bland meal. You might have pasta with it, but without any FLAVOR, it's barely better than ash in your mouth.")
        print()
        time.sleep(2)
        print("---You Have Cooked A Lethally Bland Meal---")
        DeathScreen.deathscreen()

        
    elif globalVariables.delichosen == 0: #Triggers if the player doesn't have meat.
        print("You forgot the meat!")
        print()
        time.sleep(0.5)
        print("You return home and cook a meal completely devoid of anything savory. It might have flavor, and it might have pasta, but what's the point of pasta if it's JUST pasta?")
        print()
        time.sleep(3)
        print("---You Have Accidentally Gone Vegan---")
        DeathScreen.deathscreen()
    else:
        victorycondition = 1 #Triggers if the player has all three ingredients.
        print("You put your "+ globalVariables.pastachoice + " and your " + globalVariables.spicechoice + " and your " + globalVariables.delichoice + " onto the conveyor belt.")
        time.sleep(3)
        print("You pay for your food, leave the store, and head home to cook a delicious meal! Great work!")
        print()
    if victorycondition == 1:
        time.sleep(4)
        print("It's been a rough day, but you did exactly what you wanted to do!")
        print()
        time.sleep(3)
        print("Before you dig into your dinner, you whip up a nice name for it. You eventually decide on...")
        if globalVariables.pastachoice == "macaroni noodles": #Determines a set of adjectives based on each ingredient the player has in their inventory
            PastaAdjective = "Macaroni "
        elif globalVariables.pastachoice == "lasagne noodles":
            PastaAdjective = "Lasagna "

        elif globalVariables.pastachoice == "fettuccini noodles":
            PastaAdjective = "Pasta "
        elif globalVariables.pastachoice == "agnoletti noodles":
            PastaAdjective = "Pocket "
        if globalVariables.delichoice == "sliced meat":
            MeatAdjective = "Surprise!"
        elif globalVariables.delichoice == "frozen meatballs":
            MeatAdjective = "And Meatballs!"
        elif globalVariables.delichoice == "fish filets":
            MeatAdjective = "With Salmon!"
        if globalVariables.spicechoice == "BBQ spice rub":
            SpiceAdjective = "Southern "
        elif globalVariables.spicechoice == "bottle of onion powder":
            SpiceAdjective = "Onion "
        elif globalVariables.spicechoice == "black pepper grinder":
            SpiceAdjective = "Pepper "
        elif globalVariables.spicechoice == "variety of herbs and spices":
            SpiceAdjective = "Eleven Secret Herbs & Spices "
        print(globalVariables.playername + "'s " + SpiceAdjective + PastaAdjective + MeatAdjective) #Builds a custom meal by combining all of the player's collected ingredients: Examples include "Ben's Pepper Pasta & Meatballs!"
        print("Amount of times you died:", globalVariables.deathcounter)
        print()
        globalVariables.Victory = True #Sets a variable to automatically close any possible recursion errors after the game ends.
        return()
