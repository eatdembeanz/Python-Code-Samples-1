import os
import time
import random
import globalVariables # imports the global variables
import HubWorld

def parkinglot():
##    print(globalVariables.seenitalready) # Used for testing
    Choice1 = "0"
    globalVariables.playername = input("Welcome to Pasta Dinner Pro! Please input your name.") #assigns whatever the player puts in to the playername variable, overriding the default: "Wingus"
    beginanswer = input("Would you like to begin playing? Yes/No")
    beginplay = 0
    if beginanswer == "No" or beginanswer == "no":
        print("Why did you start this up, then?")
        beginplay = 0
        time.sleep(3)
        return(exit()) #Quits the game and closes the client.
    
    elif beginanswer == "Yes":
        print("Alright, let's begin!")
        time.sleep(3)
        beginplay = 1
        
    else:
        print("Weird way to spell 'Yes', but that's alright!")
        time.sleep(3)
        beginplay = 1
    if beginplay == 1:
        print("Your car's tires squeal with a loud SCREECH! as they wheel into the parking lot of your local Jewel.")
        print()
        time.sleep(2)
        print("You know you're here for one good reason: Pasta. You've been wanting a nice, homemade pasta dinner for WEEKS, and it's only gotten worse with time. Today was the day your dire hunger for carbs and protein finally won out over your very well justified hatred of shopping here. Good lord do you hate this place.")
        print()
        time.sleep(2)
        print("Rows upon rows of parking spaces sprawl out before you. Most of the spaces near the front are occupied, but there's still a few available.")
        print()
        time.sleep(2)
        print("You assess the state of the parking lot. As far as you can tell, you've got three options:")
        print()
        time.sleep(2)
        print("1. You could park in the handicapped parking space. It's poor form; actually, it's downright EVIL. But it'd be really quick and it's not like there's any cops around... right?")
        print("2. You could try to find a parking space near the front. It could take a while, but the travel time on foot would make up for it.")
        print("3. You could take one of the many open spots near the end of the lot. It'll take you a while to travel to and from the store, but you'll feel great inside for the exercise!")
        print()
        Choice1 = "0" #Initializes the Choice1 variable and beginmodule2
        beginmodule2 = False
        while beginmodule2 == False:
            Choice1 = input("Which parking place would you like to go for? Pick 1, 2, or 3.") #Player can input 1, 2, or 3. Illegal commands causes another run of the while loop, allowing the player to choose again.
            if Choice1 == "1":
                print("You pull into the handicapped parking lot, feeling no guilt whatsoever. You look around for bystanders, and see nobody who would dare tattle on you. You step out of the car. You begin walking to the store's front door. Almost immediately, you get mowed down by a seventy-year-old grandma in a Grand Caravan.")
                print()
                time.sleep(3)
                print("YOU FAILED!!!")
                print()
                print("Well, that wasn't part of the plan! You wake up three days later in the hospital; your legs have been broken in every place possible, and you will never walk again. In the months and thousands of dollars to come, you will gradually get accustomed to your newfound handicap. A new life has begun for you, all caused by your horrible, unlawful lust for noodles. But, at the very least, next time you'll be able to actually USE that handicapped spot.")
                print()
                RestartChoice = input("Would you like to restart the game? Yes/No.")
                if RestartChoice == "Yes":
                   return(parkinglot()) #Restarts the function, as the player has died.
                else:
                   return(exit()) #Quits the game and closes the client.
            elif Choice1 == "2":
                print("Finding a parking place near the front can't be TOO bad, right? You begin circling around the parking lot, hunting for a space.")
                print()
                time.sleep(5)
                print("Nothing yet. You whirl around for another look.")
                print("The system is rolling dice for you. On a 6, you win!")
                time.sleep(2)
                parkingplacechance = random.randint(1,7) #Selects a number from 1 to 6 and enters a while loop that rerolls as long as the randint function doesn't hit 6. If it does, continues the game.
                while parkingplacechance != 6:
                    print("Nope, no spots are available. You drive around a bit more, looking for an open spot.","Rolled",parkingplacechance)
                    print()
                    time.sleep(3)
                    parkingplacechance = random.randint(1,7)
                
                print("Finally, a spot opens up! You quickly pull in, sweat flying off your forehead. At last, you've made it! Beaming with pride, you march smartly to the front door of the grocery store.")
                print()
                beginmodule2 = True
                
            elif Choice1 == "3":
                print("The back part of the parking lot is completely barren. Your only company here is a few sparse snow drifts and the seagulls. Good lord, the seagulls. The two dozen or so yards to the front door are plagued with a screeching swarm of feathered rats, ravenous for any french fries and anchovies you may have on you.")
                print()
                time.sleep(3)
                print("You make it through the front door, battered, pecked, and sobbing pathetically. A store associate, lugging a long procession of shopping carts (and vicious beak-marks), gives you a sympathetic nod.")
                print()
                beginmodule2 = True
            else:
                print("Please pick only 1, 2, or 3.")
                Choice1 = 0
        if beginmodule2 == True:
            time.sleep(3)
            print("Well, the parking lot was a whole lot worse than you could have ever imagined. At least that's usually the HARD part. Now, it's all smooth sailing: grab your food and get the hell out. It can't possibly be any harder than this, right?")
            print()
#            global seenitalready
            globalVariables.seenitalready = 0 # Notice how this is being called.
            time.sleep(5)
            HubWorld.storefront()
#print(parkinglot()) Don't need this statement since we are calling it from the main
