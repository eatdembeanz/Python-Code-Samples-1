import time #Allows for use of the 'sleep' function to create pauses in the game's narration. Good for keeping a readable pace!
import random #Allows for use of the 'randint' function to generate a seed for the RandomEvent module's random events to remain unpredictably random.
import sys #Allows use of the exit() function to end the client.
import globalVariables # imports the global variables
import Prologue
import RandomEvent
import Spices
import HubWorld
import Deli
import DeathScreen
import CheckOut

globalVariables.gVariables() # initiallizes the global variables

##print(globalVariables.seenitalready) # Used for testing

Prologue.parkinglot() #Starts the game.

##print(globalVariables.seenitalready) Used for testing.
