#Benjamin Page
#3/20/2019

###Pasta Dinner Pro v1.0


							===---GENERAL INFORMATION---===
Paste Dinner Pro is a short adventure game centered around collecting the ingredients for a pasta dinner, like a pro.

Pasta Dinner Pro is hosted on Github, and distributed manually via Benjamin Page and other owners of Pasta Dinner Pro.

Pasta Dinner Pro uses no external services, and exclusively uses the Python language.


							====---SYSTEM REQUIREMENTS---===
Pasta Dinner Pro runs on any computer capable of using the Python language. If you don't have Python installed, please visit https://python.org to download it.

To run Pasta Dinner Pro, run MainGame.py. All other files are submodules the MainGame file uses. While playing, you will be given input prompts, usually predicated by numbered lists (1.,2.,3.,etc.). Enter an appropriate character (usually a number or Yes/No) to continue the game based on that choice.

							===---CODE INFORMATION---===
Pasta Dinner Pro uses rudimentary coding language to perform what it does, largely using a series of print and sleep statements to provide exposition. Occasionally, the game stops to allow player input in the form of a single number.

Key variables are stored in the globalVariables program. These key variables are:
Keeps Track Of Player Deaths: {deathcounter}
Keeps Track Of Player Progress & Prevents Player From Redoing Sections
{
pastachosen (for Pasta aisle)
delichosen 	(for Deli aisle)
spicechosen  (for Spice aisle)
seenitalready (for HubWorld intro paragraph)
}
Keeps Track Of Player Choices:
{
delichoice (for chosen meat)
spicechoice (for chosen spices)
pastachoice (for chosen pasta)
playername (for chosen name)
}
Failsafe To Forcibly Terminate The Game On A Win:
{
Victory
}